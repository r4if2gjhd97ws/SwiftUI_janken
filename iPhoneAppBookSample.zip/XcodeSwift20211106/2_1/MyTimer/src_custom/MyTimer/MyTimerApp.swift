//
//  MyTimerApp.swift
//  MyTimer
//
//  Created by Swift-Beginners.
//

import SwiftUI

@main
struct MyTimerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
