//
//  MyOkashiApp.swift
//  MyOkashi
//
//  Created by Swift-Beginners.
//

import SwiftUI

@main
struct MyOkashiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
