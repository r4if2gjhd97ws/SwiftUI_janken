//
//  MyMapApp.swift
//  MyMap
//
//  Created by Swift-Beginners.
//

import SwiftUI

@main
struct MyMapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
