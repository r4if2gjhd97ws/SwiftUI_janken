//
//  MyCameraApp.swift
//  MyCamera
//
//  Created by Swift-Beginners.
//

import SwiftUI

@main
struct MyCameraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
