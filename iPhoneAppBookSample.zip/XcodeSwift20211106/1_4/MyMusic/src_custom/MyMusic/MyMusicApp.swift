//
//  MyMusicApp.swift
//  MyMusic
//
//  Created by Swift-Beginners on 2021/07/23.
//

import SwiftUI

@main
struct MyMusicApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
