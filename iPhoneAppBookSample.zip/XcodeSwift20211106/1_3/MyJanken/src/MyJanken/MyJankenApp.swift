//
//  MyJankenApp.swift
//  MyJanken
//
//  Created by Swift-Beginners.
//

import SwiftUI

@main
struct MyJankenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
